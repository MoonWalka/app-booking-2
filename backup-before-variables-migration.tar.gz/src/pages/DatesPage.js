import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import DatesList from '@/components/dates/DatesList.js';

function DatesPage() {
  const location = useLocation();
  
  // Log pour suivre chaque rendu de DatesPage et l'URL active
  useEffect(() => {
    console.log('DatesPage rendered at:', location.pathname);
    return () => {
      console.log('DatesPage unmounting from:', location.pathname);
    };
  }, [location.pathname]);

  return <DatesList />;
}

export default DatesPage;