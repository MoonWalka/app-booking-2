export const APP_NAME = 'TourCraft';
