import React from 'react';
import TachesPage from './TachesPage';

const DashboardPage = () => {
  // Le Dashboard affiche maintenant directement le système de tâches
  return <TachesPage />;
};

export default DashboardPage;
