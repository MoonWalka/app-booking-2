// Export centralisé des sections d'artiste
export { default as ArtisteBasicInfoSection } from './ArtisteBasicInfoSection';
export { default as ArtisteContactSection } from './ArtisteContactSection';
export { default as ArtisteNotesSection } from './ArtisteNotesSection';
export { default as ArtisteMembersSection } from './ArtisteMembersSection';