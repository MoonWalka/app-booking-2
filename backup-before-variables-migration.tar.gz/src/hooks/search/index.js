// src/hooks/search/index.js
export { default as useSearchAndFilter } from './useSearchAndFilter';